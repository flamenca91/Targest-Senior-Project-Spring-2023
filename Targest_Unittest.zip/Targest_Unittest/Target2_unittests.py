import unittest
import Targest2

class TestGenerateReport(unittest.TestCase):
    Targest2.generateReport()

    def test_filename(self):
        expected_output = ["HDS_new_pump", "HRS_new_pump","HTP_new_pump", "HTR_new_pump", "PRS_new_pump", "RiskAnalysis_Pump",
                           "SDS_New_pump_x04", "SRS_ACE_Pump_X01", "SRS_BolusCalc_Pump_X04", "SRS_DosingAlgorithm_X03",
                           "SVaP_new_pump", "SVaTR_new_pump", "SVeTR_new_pump", "URS_new_pump"]

        self.assertEqual(Targest2.filename_collection, expected_output)

    def test_parent_tags(self):
        expected_output = [['PUMP:HRD:100', 'PUMP:HRD:105', 'PUMP:HRD:1000', 'PUMP:HRD:3330', 'PUMP:HRD:3350'],
                           ['PUMP:HRS:100', 'PUMP:HRS:105', 'PUMP:HRS:1000', 'PUMP:HRS:3330', 'PUMP:HRS:3340',
                            'PUMP:HRS:3350'], ['PUMP:HTP:100', 'PUMP:HTP:200', 'PUMP:HTP:300', 'PUMP:HTP:400',
                            'PUMP:HTP:500', 'PUMP:HTP:1100', 'PUMP:HTP:1200', 'PUMP:HTP:1300', 'PUMP:HTP:1400',
                            'PUMP:HTP:1500'], ['PUMP:HTR:100', 'PUMPHTR:200', 'PUMP:HTR:300', 'PUMP:HTR:400',
                            'PUMP:HTR:500', 'PUMP:HTR:1100', 'PUMP:HTR:1200', 'PUMP:HTR:1300', 'PUMP:HTR:1400',
                            'PUMP:HTR:1500'],['PUMP:PRS:1', 'PUMP:PRS:2', 'PUMP:PRS:3', 'PUMP:PRS:4', 'PUMP:PRS:5',
                            'PUMP:PRS:8', 'PUMP:PRS:10', 'PUMP:PRS:100', 'PUMP:PRS:105', 'PUMP:PRS:1000',
                            'PUMP:PRS:3330', 'PUMP:PRS:3340', 'PUMP:PRS:3350', 'PUMP:PRS:4000'],['PUMP:RISK:10',
                            'PUMP:RISK:20', 'PUMP:RISK:30', 'PUMP:RISK:40', 'PUMP:RISK:50'], ['PUMP:SDS:10',
                            'PUMP:SDS:20', 'PUMP:SDS:30', 'PUMP:SDS:40', 'PUMP:SDS:50', 'PUMP:SDS:60', 'PUMP:SDS:70'],
                           ['ACE:SRS:1', 'ACE:SRS:2', 'ACE:SRS:5', 'ACE:SRS:6', 'ACE:SRS:10', 'ACE:SRS:100'],
                           ['BOLUS:SRS:1', 'BOLUS:SRS:2', 'BOLUS:SRS:5', 'BOLUS:SRS:6', 'BOLUS:SRS:8', 'BOLUS:SRS:12'],
                           ['AID:SRS:1', 'AID:SRS:2', 'AID:SRS:10', 'AID:SRS:12', 'AID:SRS:20'], ['PUMP:SVAL:100',
                            'PUMP:SVAL:200', 'PUMP:SVAL:300', 'PUMP:SVAL:400', 'PUMP:SVAL:500'], ['PUMP:SVATR:100',
                            'PUMP:SVATR:200', 'PUMP:SVATR:300', 'PUMP:SVATR:400', 'PUMP:SVATR:500'], ['PUMP:UT:100',
                            'PUMP:UT:110', 'PUMP:UT:120', 'PUMP:UT:130', 'PUMP:UT:140', 'PUMP:UT:150', 'PUMP:UT:160',
                            'PUMP:UT:170', 'PUMP:UT:180', 'PUMP:UT:190', 'PUMP:UT:200', 'PUMP:UT:210', 'PUMP:UT:220',
                            'PUMP:INS:100', 'PUMP:INS:110', 'PUMP:INS:120', 'PUMP:INS:130', 'PUMP:INS:140',
                            'PUMP:INS:150', 'PUMP:INS:160', 'PUMP:INS:170', 'PUMP:INS:180', 'PUMP:INS:190',
                            'PUMP:INS:200', 'PUMP:INS:210', 'PUMP:INS:220'], ['PUMP:URS:1', 'PUMP:URS:3', 'PUMP:URS:8',
                            'PUMP:URS:10', 'PUMP:URS:100', 'PUMP:URS:103', 'PUMP:URS:1000', 'PUMP:URS:3330',
                            'PUMP:URS:3350', 'PUMP:URS:4000']]

        #targest.generateReport()
        self.assertEqual(Targest2.parents_list, expected_output)

if __name__ == '__main__':
    unittest.main()


"""
import unittest
from Targest2 import generateReport
from unittest.mock import patch, MagicMock

class MyTest(unittest.TestCase):
    @patch("generateReport.filepath3", new=MagicMock())
    def test_global_var1(self, mock_filepath3):
        generateReport()
        expected_output = ["HDS_new_pump", "HTP_new_pump", "HTR_new_pump", "PRS_new_pump", "RiskAnalysis_Pump",
                           "SDS_New_pump_x04", "SRS_ACE_Pump_X01", "SRS_BolusCalc_Pump_X04", "SRS_DosingAlgorithm_X03",
                           "SVaP_new_pump", "SVaTR_new_pump", "SVeTR_new_pump", "URS_new_pump"]

        self.assertEqual(mock_filepath3, expected_output)

if __name__ == '__main__':
    unittest.main()





import unittest
import os
from Targest2 import generateReport

class TestGenerateReport(unittest.TestCase):
    def test_generate_report(self):
        filepath1 = "test_files/requirements.xlsx"
        filepath2 = "test_files/test_cases.xlsx"
        filepath3 = "test_files/updated_docs"
        generateReport(filepath1, filepath2, filepath3)
        expected_output = ["HDS_new_pump", "HTP_new_pump", "HTR_new_pump", "PRS_new_pump", "RiskAnalysis_Pump",
                           "SDS_New_pump_x04", "SRS_ACE_Pump_X01", "SRS_BolusCalc_Pump_X04", "SRS_DosingAlgorithm_X03",
                           "SVaP_new_pump", "SVaTR_new_pump", "SVeTR_new_pump", "URS_new_pump"]
        output = os.listdir(filepath3)
        self.assertEqual(output, expected_output)

if __name__ == '__main__':
    unittest.main()



import unittest
import os
import Targest2

class TestGenerateReport(unittest.TestCase):

    def test_file_path(self):
        # Test case for the output of filepath3
        Targest2.generateReport()
        expected_output = ["HDS_new_pump", "HTP_new_pump", "HTR_new_pump", "PRS_new_pump", "RiskAnalysis_Pump",
                           "SDS_New_pump_x04", "SRS_ACE_Pump_X01", "SRS_BolusCalc_Pump_X04", "SRS_DosingAlgorithm_X03",
                           "SVaP_new_pump", "SVaTR_new_pump", "SVeTR_new_pump", "URS_new_pump"]
        output = os.listdir(Targest2.filepath3)
        self.assertEqual(output, expected_output)

if __name__ == '__main__':
    unittest.main()



import unittest
from Targest2 import generateReport

class TestFooLlist(unittest.TestCase):
    def test_genReport_filepath3(self):
        # Call the function
        result = generateReport()

        # Get the value of the filepath3 variable from the function's scope
        filepath3 = generateReport.__code__.co_consts[26]

        # Assert that the Llist variable is equal to the expected list
        #expected_output = [1, 2, 3, 4, 5, 6, 7, 8, 9]
        expected_output = ["HDS_new_pump", "HTP_new_pump", "HTR_new_pump", "PRS_new_pump", "RiskAnalysis_Pump",
                           "SDS_New_pump_x04", "SRS_ACE_Pump_X01", "SRS_BolusCalc_Pump_X04", "SRS_DosingAlgorithm_X03",
                           "SVaP_new_pump", "SVaTR_new_pump", "SVeTR_new_pump", "URS_new_pump"]
        self.assertEqual(filepath3, expected_output)

        # Assert that the function's return value is equal to the expected list
        #self.assertEqual(result, expected_output)

if __name__ == '__main__':
    unittest.main()




import unittest
from io import StringIO
import sys
from Targest2 import generateReport

class TestDocFiles(unittest.TestCase):
    def generateReport(self):
        # Redirect stdout to capture print statement output
        captured_output = StringIO()
        sys.stdout = captured_output

        # Call the function
        generateReport()

        # Get the output
        stdout = captured_output.getvalue().strip()

        # Split the output by newlines and remove the last element (which is the fList print statement)
        output_lines = stdout.split('\n')[:-1]

        # Assert that the output is correct
        ##expected_output = "1\n2\n3\n4\n5\n6\n7\n8\n9"
        expected_output = "HDS_new_pump.docx\nHTP_new_pump.docx\nHTR_new_pump.docx\nPRS_new_pump.docx \
        \nRiskAnalysis_Pump.docx\nSDS_New_pump_x04.docx\nSRS_ACE_Pump_X01.docx\nSRS_BolusCalc_Pump_X04.docx \
        \nSRS_DosingAlgorithm_X03.docx\nSVaP_new_pump.docx\nSVaTR_new_pump.docx\nSVeTR_new_pump.docx \
        \nURS_new_pump.docx"
        self.assertEqual('\n'.join(output_lines), expected_output)
        #self.assertEqual(stdout, expected_output)

        # Assert that the function returns the correct value
        ##expected_list = [1, 2, 3, 4, 5, 6, 7, 8, 9]
        ##self.assertEqual(fList, expected_list)

        # Reset stdout
        sys.stdout = sys.__stdout__


import sys
import unittest
from io import StringIO
import Targest2

class TestDocFiles(unittest.TestCase):
    def setup(self):
        self.held, sys.stdout = sys.stdout, StringIO()

    def testFile(self):
        self.generateReport()
        self.assertIn(sys.stdout.getvalue.strip(), ["HDS_new_pump.docx", "HTP_new_pump.docx", "HTR_new_pump.docx", \
             "PRS_new_pump.docx", "RiskAnalysis_Pump.docx", "SDS_New_pump_x04.docx", "SRS_ACE_Pump_X01.docx", \
             "SRS_BolusCalc_Pump_X04.docx", "SRS_DosingAlgorithm_X03.docx", "SVaP_new_pump.docx", \
             "SVaTR_new_pump.docx", "SVeTR_new_pump.docx", "URS_new_pump.docx"], "Key not in the container")



if __name__ == '__main__':
    unittest.main()
"""