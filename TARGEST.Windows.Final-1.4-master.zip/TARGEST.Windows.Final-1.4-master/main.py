import Gui # Imports the Gui.py file

if __name__ == "__main__" :
    Gui.GUI1() # Calls the function GUI1() from the Gui.py file
    
